from flask import Flask, redirect, url_for, session, request, jsonify
from authlib.integrations.flask_client import OAuth
import json
import os

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Load client secrets
with open('client_secret.json') as f:
    secrets = json.load(f)['web']

app.config['GOOGLE_CLIENT_ID'] = secrets['client_id']
app.config['GOOGLE_CLIENT_SECRET'] = secrets['client_secret']

oauth = OAuth(app)
google = oauth.register(
    name='google',
    client_id=app.config['GOOGLE_CLIENT_ID'],
    client_secret=app.config['GOOGLE_CLIENT_SECRET'],
    authorize_url='https://accounts.google.com/o/oauth2/auth',
    authorize_params=None,
    access_token_url='https://accounts.google.com/o/oauth2/token',
    access_token_params=None,
    refresh_token_url=None,
    redirect_uri='http://localhost:5000/callback',
    client_kwargs={
        'scope': 'https://www.googleapis.com/auth/spreadsheets https://www.googleapis.com/auth/drive https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/gmail.readonly',
        'token_endpoint_auth_method': 'client_secret_post',
        'token_placement': 'header',
    }
)

@app.route('/')
def index():
    return '<a href="/login">Sign in with Google</a>'

@app.route('/login')
def login():
    redirect_uri = url_for('authorized', _external=True)
    return google.authorize_redirect(redirect_uri)

@app.route('/logout')
def logout():
    session.pop('user', None)
    session.pop('token', None)
    return redirect(url_for('index'))

@app.route('/callback')
def authorized():
    token = google.authorize_access_token()
    resp = google.get('userinfo')
    user_info = resp.json()
    session['user'] = user_info
    session['token'] = token
    return redirect(url_for('profile'))

@app.route('/profile')
def profile():
    if 'user' not in session:
        return redirect(url_for('index'))
    return jsonify(session['user'])

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)